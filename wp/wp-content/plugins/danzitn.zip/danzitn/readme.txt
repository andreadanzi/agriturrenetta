=== DanziTN ===
Contributors: andreadanzi
Tags: download, downloads, monitor, hits, download monitor, tracking, admin, count, counter, files, versions, download count, logging
Requires at least: 3.5
Tested up to: 3.7
Stable tag: 1.3.1
License: GPLv3

DanziTN is a plugin for integrating wordpress web site with the CRM backend

== Description ==

DanziTN is a plugin for integrating wordpress web site with the CRM backend

= Features =

